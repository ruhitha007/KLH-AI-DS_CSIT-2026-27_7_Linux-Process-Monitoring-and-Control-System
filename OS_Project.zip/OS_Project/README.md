# Linux Process Monitoring and Control System

A read-only-and-control Linux Task Manager-style desktop application written in Python.
It discovers processes through `/proc`, measures CPU and memory usage, monitors them live in
a Tkinter table, and lets the user pause, resume, or terminate a process they have explicitly
selected.

---

## 1. Project objective

To demonstrate how the Linux `/proc` pseudo-filesystem and POSIX signals can be used from a
user-space program to build an operating-system-level process monitor: read process state,
compute resource usage, present it in a graphical interface, and control processes safely
through the kernel's signal interface.

## 2. Problem statement

Linux already ships with tools such as `top`, `htop`, and `ps`, but they are command-line
oriented and do not explain how the data is obtained. A student studying operating systems
needs to see the connection between kernel interfaces and user-space code: which files the
kernel exposes, what each field means, how CPU time becomes a percentage, and how a process
is suspended or asked to exit.

At the same time, process control is dangerous if it is careless. Any program that can signal
processes can freeze a user's desktop or kill a critical service. This project therefore
enforces a simple rule: **the application only ever acts on a process the user has explicitly
selected and explicitly acted on.** Nothing is controlled automatically, and the only
termination path is a confirmed request.

## 3. Features

**Process monitoring**

- PID, process name, username, state, parent PID
- CPU usage percentage
- Memory usage percentage
- Runtime and full command line in a details window

**Graphical interface**

- Fixed-column process table with a vertical scrollbar
- Manual **Refresh** button
- Automatic periodic refresh (every 1.5 seconds)
- Process selection with the PID shown in the status bar
- Search by PID, process name, or username
- **Clear** button that restores the full list
- **View Details** window with the full record for one process
- Status area showing process count, selection, notes, and the result of the last action

**Process control**

- **Pause** → `SIGSTOP`
- **Resume** → `SIGCONT`
- **Terminate** → `SIGTERM`, behind a confirmation dialog naming the process and PID

**Safety**

- No action is possible without a selected process
- Termination always requires confirmation
- No automatic control, no `SIGKILL`, no forceful options
- Invalid PIDs, vanished processes, and permission errors are reported clearly

## 4. Technology used

| Area | Choice |
| --- | --- |
| Language | Python 3.8+ |
| GUI toolkit | Tkinter / ttk (standard library) |
| Process data | Linux `/proc` pseudo-filesystem |
| Control | POSIX signals via `os.kill()` |
| Username lookup | `pwd` module |
| Tests | `unittest` with `unittest.mock` |
| Type hints | `typing` (standard library) |

There are **no third-party packages**. No `requirements.txt` is needed or included, because
everything used ships with Python or with the OS package that provides Tkinter.

## 5. System requirements

**To run (Linux, the intended platform)**

- Linux with a mounted `/proc` filesystem (any modern distribution)
- Python 3.8 or newer
- Tkinter, installed with the OS package manager:
  - Debian/Ubuntu: `sudo apt install python3-tk`
  - Fedora: `sudo dnf install python3-tkinter`
  - Arch: `sudo pacman -S tk`
- A graphical display. Running as root is not required and is not recommended.

**To run the tests**

- Python 3.8 or newer
- No display required for the backend tests; GUI tests skip themselves if no display exists

## 6. Project architecture

```text
┌──────────────────────────────────────────────┐
│  Tkinter GUI  (gui/main_window.py)           │
│  table · search · details · status bar       │
│  user actions only; no parsing, no signals   │
└───────────────┬──────────────────┬───────────┘
                │ requests records │ control requests
                ▼                  ▼
┌──────────────────────────┐  ┌────────────────────────────┐
│ ProcessManager           │  │ ProcessController          │
│ backend/process_manager  │  │ backend/process_controller │
│ discovery, /proc parsing,│  │ SIGSTOP / SIGCONT /        │
│ CPU, memory, runtime     │  │ SIGTERM via os.kill()      │
└────────────┬─────────────┘  └──────────────┬─────────────┘
             │                               │
             ▼                               ▼
      ┌─────────────┐                 ┌──────────────────┐
      │  Linux /proc│                 │  Linux kernel    │
      │  + pwd      │                 │  signal handling │
      └─────────────┘                 └──────────────────┘
```

Rules that keep the project understandable:

1. The GUI never reads or parses `/proc`. It asks a backend class for finished records.
2. The GUI never calls `os.kill()`. It asks `ProcessController` to act on a PID.
3. `ProcessController` never reads `/proc`. It only sends the three allowed signals.
4. `ProcessManager` and `ProcessController` do not import each other, so monitoring and
   control stay independent.

## 7. Project structure

```text
project/
├── main.py                      entry point: GUI by default, --console for a terminal listing
├── backend/
│   ├── __init__.py              package exports
│   ├── process_manager.py       /proc discovery, parsing, CPU/memory/runtime
│   └── process_controller.py    SIGSTOP / SIGCONT / SIGTERM and their error messages
├── gui/
│   ├── __init__.py              package exports
│   └── main_window.py           Tkinter window, table, search, details, control buttons
├── tests/
│   ├── test_process_manager.py  backend tests against a fake /proc tree
│   ├── test_process_controller.py signal tests with a recording fake sender
│   └── test_main_window.py      GUI tests with fake backend objects
└── README.md
```

## 8. Explanation of `/proc`

`/proc` is not a real directory on disk. It is a pseudo-filesystem that the kernel mounts so
that user-space programs can read live process and system information. Each file is generated
by the kernel when it is opened, which is why the values always reflect the current state of
the system.

Files used by this project:

| Path | Contents used |
| --- | --- |
| `/proc/<pid>/stat` | Process name, state, parent PID, cumulative user/system CPU ticks, start time in ticks since boot |
| `/proc/<pid>/status` | Real user ID (`Uid:` line) and resident set size (`VmRSS:` line) |
| `/proc/<pid>/cmdline` | Full command line, arguments separated by NUL bytes |
| `/proc/meminfo` | `MemTotal`, total physical memory |
| `/proc/uptime` | Seconds since boot |

Parsing notes:

- `/proc/<pid>/stat` puts the process name in parentheses and the name itself may contain
  spaces and parentheses. The file is therefore split on the **last** `)`, not the first.
- Non-numeric entries in `/proc` (`self`, `sys`, `meminfo`, …) are not processes and are ignored.
- A process can exit at any moment, so every read can fail. Missing or malformed data is
  reported as unavailable instead of raising.
- Kernel threads have an empty `cmdline` file, which correctly yields "no command line".

## 9. Process information collection

`ProcessManager.get_processes()` lists `/proc`, keeps only numeric entries, and returns the
readable processes sorted by PID. `ProcessManager.get_process_details(pid)` returns one
complete `ProcessInfo` record:

| Field | Source |
| --- | --- |
| `pid` | Directory name |
| `name` | `stat`, inside the parentheses |
| `state` | `stat` field 3 |
| `ppid` | `stat` field 4 |
| `username` | `Uid:` from `status`, resolved through `pwd.getpwuid()` |
| `command_line` | `cmdline`, NUL bytes replaced by spaces |
| `cpu_percent` | Difference between two `stat` CPU samples |
| `memory_percent` | `VmRSS` compared with `MemTotal` |
| `runtime_seconds` | `/proc/uptime` minus the start time |

The stat file is read **once** per lookup and reused for the identity, CPU, and runtime values,
so a refresh does not re-read the same file several times for one process.

## 10. CPU usage calculation

The kernel reports cumulative CPU time per process, not a percentage, so two samples are
needed:

```text
elapsed_ticks  = current (utime + stime) - previous (utime + stime)
cpu_seconds    = elapsed_ticks / SC_CLK_TCK
CPU %          = (cpu_seconds / elapsed_seconds) × 100
```

- `SC_CLK_TCK` comes from `os.sysconf("SC_CLK_TCK")` and is normally 100 on Linux.
- The first sample is taken at startup by `capture_cpu_baseline()`, so the very first table can
  show `N/A`. Every later refresh (automatic or manual) uses the previous refresh as the earlier
  sample.
- Each PID's sample also stores its start time. If the start time changes, the PID was reused by
  a different process and the CPU value is discarded rather than reported wrongly.
- The value is the share of **one** CPU core, so a process using two full cores on a multi-core
  machine can legitimately read above 100%.

## 11. Memory usage calculation

```text
Memory % = (VmRSS / MemTotal) × 100
```

`VmRSS` is the resident set size from `/proc/<pid>/status`, in kB, and `MemTotal` is total
physical memory from `/proc/meminfo`, in kB. Both must be readable and `MemTotal` must be
greater than zero, otherwise memory usage is shown as `N/A`.

## 12. Process states

The `stat` file contains a one-letter state code. The details window shows a readable name next
to the code:

| Code | Meaning in this project | Common cause |
| --- | --- | --- |
| `R` | Running | Executing or ready to run |
| `S` | Sleeping | Waiting for an event, usually normal |
| `D` | Waiting | Uninterruptible wait, often on disk or I/O |
| `Z` | Zombie | Exited, waiting to be reaped by its parent |
| `T` | Stopped | Suspended, e.g. after `SIGSTOP` or a debugger break |
| `I` | Idle | Kernel idle thread |

A state that is not listed is displayed unchanged, so a new kernel state is still visible.

## 13. Linux signals

A signal is a software interrupt delivered by the kernel to a process. This project uses the
`os.kill(pid, signal_number)` system call directly. It never runs a shell command such as
`kill` or `pkill`, and it never uses a subprocess.

| Button | Signal | Number on Linux | Meaning |
| --- | --- | --- | --- |
| Pause | `SIGSTOP` | 19 | Suspends the process |
| Resume | `SIGCONT` | 18 | Continues a suspended process |
| Terminate | `SIGTERM` | 15 | Asks the process to terminate |

Only these three signals are defined in `backend/process_controller.py`, and a test enforces
that no other signal name appears in the module. `SIGKILL` and other forceful signals are
deliberately unavailable.

### 14. SIGSTOP — pause

`SIGSTOP` suspends a process immediately and unconditionally. The process cannot catch,
block, or ignore it, so the pause always takes effect. The process state in `/proc` changes to
`T`, which the table shows on the next refresh. CPU consumption stops while it is stopped.

The user resumes it with the **Resume** button. Because `SIGSTOP` cannot be ignored, a stopped
process stays stopped even if it tries to exit, so the resume button matters.

### 15. SIGCONT — resume

`SIGCONT` continues a process that was stopped by `SIGSTOP` (or by a terminal job-control
stop), and its state changes back to `R` or `S`. `SIGCONT` is also the way to wake a process
that is being traced, and it is safe to send to a process that is not stopped, so the button
never needs a confirmation.

### 16. SIGTERM — graceful termination request

`SIGTERM` asks a process to shut down. It is a request, not a forced kill: a well-behaved
program can catch it, stop accepting new work, save state, and exit with a status code. This
is the correct signal for "please close", and it is why the application offers no `SIGKILL`
alternative.

Because the outcome is up to the target program, the application asks for confirmation first,
naming the process and its PID, and sends nothing if the dialog is dismissed. A process that
ignores `SIGTERM` keeps running, and the row simply stays in the table.

## 17. GUI workflow

1. `main.py` starts the Tkinter application unless `--console` is given.
2. The window is built: header, search and control toolbar, process table, status bar.
3. `capture_cpu_baseline()` records the first CPU sample for every process.
4. `refresh()` reads a full snapshot and fills the table.
5. Automatic refresh is scheduled, and the window enters the Tkinter event loop.
6. Each refresh keeps the search text, the filtered rows, and the selected PID, and clears the
   selection safely if the selected process is gone.
7. Clicking a row stores its PID; the status bar shows `Selected PID: <pid>`.
8. **View Details** re-reads that one process from the backend and opens a read-only window.
9. **Pause**, **Resume**, and **Terminate** act only on the selected PID.

## 18. Search and filter workflow

1. Typing in the search box starts a 250 ms debounce (`SEARCH_DELAY_MS`) instead of filtering
   on every keystroke.
2. When typing pauses, the cached snapshot is filtered with a case-insensitive substring match
   against PID, process name, and username.
3. Only matching rows are inserted into the table; the status bar shows
   `Showing: X of Y matching "<query>"`.
4. Filtering reads the in-memory snapshot, so typing never touches `/proc`.
5. **Clear** empties the box and restores every row.
6. A refresh re-applies the current search, so a search of `firefox` keeps showing only Firefox
   while the values inside those rows keep updating.
7. If the search hides the selected process, the selection is cleared and the status area
   explains that the process is hidden by the current search.

## 19. Automatic refresh

- The interval is the single constant `AUTO_REFRESH_INTERVAL_MS` in `gui/main_window.py`
  (1500 ms), near the top of the file.
- Each tick runs one refresh and then schedules the next one with Tkinter's `after()`. There
  is no `while True` loop and no background thread.
- A guard prevents a second refresh from starting while one is still running, so a slow
  machine cannot pile up overlapping refreshes.
- A refresh updates the table, the process count, CPU and memory values, the search results,
  and the selection in one pass.
- If the backend cannot be read, the error is reported once instead of on every interval, and
  monitoring continues so the error clears as soon as access returns.
- **Refresh** still performs an immediate update on demand.

## 20. Error and permission handling

| Situation | Behaviour |
| --- | --- |
| No process selected | Warning dialog: select a process first |
| Invalid PID (not a positive integer) | `ProcessControlError`: "not a valid process ID" |
| Process already exited | "PID n no longer exists"; the row disappears on the next refresh |
| Signal not permitted | "Permission denied: PID n is probably owned by another user or is a protected system process" |
| Other `OSError` | Reported with the system error text |
| Signal unsupported on the platform | "SIGSTOP is not available on <platform>" |
| `/proc/<pid>` unreadable or malformed | The process is skipped, counted as unavailable, and the run continues |
| No readable processes at all | Status: "No readable processes were found. Check access to /proc." |
| Unexpected backend failure | Logged with a traceback, one friendly dialog, table left intact |

Design rules followed here:

- The GUI never shows a Python traceback to the user; details go to the log.
- Failures are never silently ignored: they are counted, logged, and reported.
- Permission errors are normal, not exceptional. Controlling a process owned by another user
  requires that user's privileges, so a normal user account sees a clear message instead of a
  crash. Running the application as root widens what it can control, which is a risk, not a
  fix.

## 21. Installation

On Debian or Ubuntu:

```bash
sudo apt update
sudo apt install python3 python3-tk
```

Then place the project directory anywhere and run it from that directory. No build step, no
package installation, and no `pip install` are required.

## 22. How to run

```bash
python3 main.py
```

A terminal listing is also available, which is convenient over SSH where no display exists:

```bash
python3 main.py --console
```

## 23. How to run the tests

```bash
python3 -m unittest discover -s tests -v
```

Syntax and compilation checks:

```bash
python3 -m compileall .
```

What the tests cover:

| Test file | Focus |
| --- | --- |
| `tests/test_process_manager.py` | `/proc` discovery, `stat` parsing, CPU between two samples, memory from `VmRSS`/`MemTotal`, command line, runtime, permission and disappearing-process cases |
| `tests/test_process_controller.py` | Each signal, the production `os.kill` path, invalid PIDs, vanished processes, permission errors, and the three-signal allow-list |
| `tests/test_main_window.py` | Table population, selection preservation, unavailable processes, backend failure, search behaviour, details window, control actions, confirmation, and automatic refresh scheduling |

No test sends a real signal: signals are recorded by a fake sender, and GUI tests use fake
backend objects and a withdrawn window, so nothing blocks on an event loop.

Latest recorded result on the development machine (Windows, Python 3.11):

```text
Ran 44 tests in 3.0s
OK (skipped=1)
```

43 passed, 1 skipped, 0 failures.

## 24. Windows development limitations

The project was developed on Windows, which changes what could be verified:

- There is no `/proc` on Windows, so the table is empty and no real process data was read.
- `os.sysconf("SC_CLK_TCK")` does not exist, so CPU and runtime values cannot be produced.
- `signal.SIGSTOP` and `signal.SIGCONT` do not exist on Windows. The backend resolves the three
  signals with `getattr`, so the module still imports and returns a clear "not available on this
  platform" error instead of crashing. This is why exactly one test, which asserts that the
  constants equal the real POSIX signal numbers, is skipped on Windows.
- `pwd` does not exist, so usernames cannot be resolved; the backend treats it as optional.
- Signal permission behaviour, the real effect of `SIGSTOP` on a process state, and
  `SIGTERM` cleanup could not be exercised on Windows.

**Verified on Linux: none.** Everything Linux-specific in this project is currently
**tested with mocks on Windows**. The Linux claims in this README are based on the documented
behaviour of `/proc`, `os.kill()`, and POSIX signals, not on an observed Linux run.

## 25. Linux testing requirement

Before this project can be presented as verified, it must be run on a real Linux system, either
a physical machine, a virtual machine, or a cloud instance. A minimal checklist:

```bash
python3 -m unittest discover -s tests -v     # expect 44 tests, 0 skipped
python3 main.py                              # table should populate within 1.5 s
```

Then confirm by hand:

1. The table lists real processes with usernames, states, CPU, and memory values.
2. CPU and memory percentages change between refreshes for a busy process.
3. Runtime values are plausible and increase over time.
4. Searching `firefox` keeps only matching rows, and the values inside them keep updating.
5. **Pause** changes the selected process state to `T`; **Resume** returns it to `R`/`S`.
6. **Terminate** on a disposable test process, for example one started with `sleep 600`,
   removes the row after confirmation.
7. Pausing a process owned by another user reports a permission error instead of crashing.

Suggested cloud or VM options for a college demonstration: Ubuntu Server on a free-tier VM,
VirtualBox with an Ubuntu ISO, or a Raspberry Pi image.

## 26. Known limitations

- **Unverified on Linux.** All Linux-specific behaviour is currently mocked on Windows; see
  sections 24 and 25.
- **CPU percentage is per single core.** A multi-threaded process can exceed 100%. Values are
  not normalised to the number of cores.
- **The first CPU sample is always `N/A`.** Two samples are required by definition, so the very
  first table has no CPU column values yet.
- **Runtime needs `/proc/uptime`.** In a restricted container it can be unavailable and shows
  `N/A`.
- **Refresh is synchronous.** Reading every process happens on the Tkinter main thread, so on a
  machine with very many processes the window may be briefly busy during each 1.5 s refresh.
  This is the direct trade-off for not using a background thread.
- **The details window is a snapshot.** It shows the values read when it was opened and does
  not live-update while it stays open.
- **Signals can be ignored.** `SIGTERM` is a request, and a program may handle or ignore it.
  There is no `SIGKILL` option by design.
- **`SIGSTOP` cannot be ignored**, so a stopped process will not exit on its own until it is
  resumed.
- **No `nice`/priority control, no process tree, no charts, no network features, and no
  database or history.** These are outside the scope of the project.
- **Permission level defines reach.** A normal user can only control their own processes; the
  application is not intended to be run as root.

## 27. References

- `man 5 proc` — the `/proc` filesystem
- `man 2 kill` — the `kill(2)` system call and its error codes
- `man 7 signal` — signal semantics
- `man 2 os_sysconf` — `SC_CLK_TCK`
- Python documentation: `os.kill`, `os.sysconf`, `signal`, `tkinter`
