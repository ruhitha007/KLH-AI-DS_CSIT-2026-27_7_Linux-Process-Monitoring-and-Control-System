import unittest
from unittest.mock import patch

from backend.process_controller import ProcessControlError
from backend.process_manager import ProcessInfo

try:
    import tkinter
except ImportError as import_error:
    TKINTER_IMPORT_ERROR = import_error
else:
    TKINTER_IMPORT_ERROR = None
    from gui.main_window import (
        AUTO_REFRESH_INTERVAL_MS,
        ProcessMonitorApp,
        format_process_row,
        format_runtime,
    )


class FakeProcessManager:
    """Small ProcessManager stand-in that never reads /proc."""

    def __init__(self, processes, unavailable_pids=()):
        self.processes = list(processes)
        self.details = {process.pid: process for process in processes}
        for pid in unavailable_pids:
            self.details.pop(pid, None)
        self.baseline_count = 0
        self.get_processes_calls = 0
        self.fail = False

    def capture_cpu_baseline(self):
        self.baseline_count += 1

    def get_processes(self):
        self.get_processes_calls += 1
        if self.fail:
            raise OSError("simulated backend failure")
        return list(self.processes)

    def get_process_details(self, pid):
        return self.details.get(pid)


class FakeProcessController:
    """ProcessController stand-in that records calls and never signals anything."""

    def __init__(self):
        self.calls = []
        self.error = None

    def _record(self, action, pid):
        self.calls.append((action, pid))
        if self.error is not None:
            raise self.error

    def pause_process(self, pid):
        self._record("pause", pid)

    def resume_process(self, pid):
        self._record("resume", pid)

    def terminate_process(self, pid):
        self._record("terminate", pid)


@unittest.skipUnless(
    TKINTER_IMPORT_ERROR is None,
    "Tkinter is not available: {}".format(TKINTER_IMPORT_ERROR),
)
class MainWindowTests(unittest.TestCase):
    def setUp(self):
        try:
            self.root = tkinter.Tk()
        except tkinter.TclError as error:
            self.skipTest("Tkinter display is not available: {}".format(error))
        self.root.withdraw()
        self.addCleanup(self.root.destroy)

    @staticmethod
    def make_process(pid=1421, name="firefox", username="user"):
        return ProcessInfo(
            pid=pid,
            name=name,
            state="R",
            ppid=532,
            username=username,
            command_line=name,
            cpu_percent=8.3,
            memory_percent=5.7,
            runtime_seconds=120.0,
        )

    def test_refresh_populates_table_and_status(self):
        manager = FakeProcessManager([self.make_process(1), self.make_process(1421)])

        app = ProcessMonitorApp(self.root, manager)

        self.assertEqual(sorted(app.tree.get_children()), ["1", "1421"])
        self.assertIn("Processes: 2", app.process_count_text.get())
        self.assertEqual(manager.baseline_count, 1)
        self.assertEqual(
            app.tree.item("1421", "values"),
            format_process_row(self.make_process(1421)),
        )

    def test_refresh_preserves_an_existing_selection(self):
        manager = FakeProcessManager([self.make_process(1421)])
        app = ProcessMonitorApp(self.root, manager)
        app.tree.selection_set("1421")
        app._on_process_selected()

        app.refresh()

        self.assertEqual(app.selected_pid, 1421)
        self.assertEqual(app.tree.selection(), ("1421",))
        self.assertIn("Selected PID: 1421", app.selected_pid_text.get())

    def test_refresh_skips_a_process_that_disappeared(self):
        manager = FakeProcessManager(
            [self.make_process(1), self.make_process(532)],
            unavailable_pids=(532,),
        )

        app = ProcessMonitorApp(self.root, manager)

        self.assertEqual(list(app.tree.get_children()), ["1"])
        self.assertIn("Unavailable: 1", app.process_count_text.get())
        self.assertIn("could not be read", app.status_note_text.get())

    def test_refresh_clears_selection_when_process_is_gone(self):
        manager = FakeProcessManager([self.make_process(1421)])
        app = ProcessMonitorApp(self.root, manager)
        app.tree.selection_set("1421")
        app._on_process_selected()
        manager.details.clear()

        app.refresh()

        self.assertIsNone(app.selected_pid)
        self.assertIn("Selected PID: None", app.selected_pid_text.get())
        self.assertIn("no longer available", app.status_note_text.get())

    def test_backend_failure_shows_friendly_error_without_clearing_table(self):
        manager = FakeProcessManager([self.make_process(1421)])
        app = ProcessMonitorApp(self.root, manager)
        manager.fail = True

        with patch("gui.main_window.messagebox.showerror") as show_error:
            with self.assertLogs("gui.main_window", level="ERROR"):
                app.refresh()

        show_error.assert_called_once()
        self.assertEqual(list(app.tree.get_children()), ["1421"])

    def type_search(self, app, text):
        """Type into the search box and let the debounced update run."""
        app.search_text.set(text)
        app._run_scheduled_search()

    @staticmethod
    def detail_texts(window):
        """Collect every static label text inside a details window."""
        texts = []
        pending = list(window.winfo_children())
        while pending:
            widget = pending.pop()
            pending.extend(widget.winfo_children())
            try:
                texts.append(str(widget.cget("text")))
            except tkinter.TclError:
                continue
        return texts

    def test_search_matches_partial_name_ignoring_case(self):
        manager = FakeProcessManager(
            [self.make_process(1, name="firefox"), self.make_process(2, name="bash")]
        )
        app = ProcessMonitorApp(self.root, manager)

        self.type_search(app, "FIRE")

        self.assertEqual(list(app.tree.get_children()), ["1"])
        self.assertIn("Showing: 1 of 2", app.process_count_text.get())

    def test_search_matches_pid(self):
        manager = FakeProcessManager(
            [self.make_process(1, name="firefox"), self.make_process(1421, name="bash")]
        )
        app = ProcessMonitorApp(self.root, manager)

        self.type_search(app, "142")

        self.assertEqual(list(app.tree.get_children()), ["1421"])

    def test_search_matches_username(self):
        manager = FakeProcessManager(
            [
                self.make_process(1, name="firefox", username="alice"),
                self.make_process(2, name="bash", username="bob"),
            ]
        )
        app = ProcessMonitorApp(self.root, manager)

        self.type_search(app, "ALICE")

        self.assertEqual(list(app.tree.get_children()), ["1"])

    def test_search_without_matches_shows_no_rows(self):
        manager = FakeProcessManager([self.make_process(1)])
        app = ProcessMonitorApp(self.root, manager)

        self.type_search(app, "does-not-exist")

        self.assertEqual(list(app.tree.get_children()), [])
        self.assertIn("Showing: 0 of 1", app.process_count_text.get())

    def test_typing_does_not_read_process_data_again(self):
        manager = FakeProcessManager(
            [self.make_process(1, name="firefox"), self.make_process(2, name="bash")]
        )
        app = ProcessMonitorApp(self.root, manager)
        calls_after_startup = manager.get_processes_calls

        self.type_search(app, "ba")
        self.type_search(app, "bas")
        app._clear_search()

        self.assertEqual(manager.get_processes_calls, calls_after_startup)

    def test_clear_search_restores_every_row(self):
        manager = FakeProcessManager(
            [self.make_process(1, name="firefox"), self.make_process(2, name="bash")]
        )
        app = ProcessMonitorApp(self.root, manager)
        self.type_search(app, "ba")

        app._clear_search()

        self.assertEqual(sorted(app.tree.get_children()), ["1", "2"])
        self.assertIn("Processes: 2", app.process_count_text.get())

    def test_selection_survives_a_search_that_still_matches(self):
        manager = FakeProcessManager(
            [self.make_process(1, name="firefox"), self.make_process(2, name="bash")]
        )
        app = ProcessMonitorApp(self.root, manager)
        app.tree.selection_set("2")
        app._on_process_selected()

        self.type_search(app, "ba")

        self.assertEqual(app.selected_pid, 2)
        self.assertEqual(app.tree.selection(), ("2",))
        self.assertIn("Selected PID: 2", app.selected_pid_text.get())

    def test_status_explains_when_a_search_hides_the_selection(self):
        manager = FakeProcessManager(
            [self.make_process(1, name="firefox"), self.make_process(2, name="bash")]
        )
        app = ProcessMonitorApp(self.root, manager)
        app.tree.selection_set("2")
        app._on_process_selected()

        self.type_search(app, "firefox")

        self.assertIsNone(app.selected_pid)
        self.assertIn("Selected PID: None", app.selected_pid_text.get())
        self.assertIn("hidden by the current search", app.status_note_text.get())

    def test_view_details_shows_selected_process_information(self):
        manager = FakeProcessManager([self.make_process(1421, name="firefox")])
        app = ProcessMonitorApp(self.root, manager)
        app.tree.selection_set("1421")
        app._on_process_selected()

        window = app._open_details_window()
        self.addCleanup(window.destroy)

        self.assertIn("1421", window.title())
        texts = self.detail_texts(window)
        self.assertIn("1421", texts)
        self.assertIn("firefox", texts)
        self.assertIn("8.3%", texts)
        self.assertIn("5.7%", texts)
        self.assertIn(format_runtime(120.0), texts)

    def test_view_details_without_a_selection_shows_a_warning(self):
        manager = FakeProcessManager([self.make_process(1421)])
        app = ProcessMonitorApp(self.root, manager)

        with patch("gui.main_window.messagebox.showwarning") as show_warning:
            result = app._open_details_window()

        self.assertIsNone(result)
        show_warning.assert_called_once()
        self.assertIn("No process selected", show_warning.call_args[0][0])

    def test_view_details_reports_a_process_that_already_exited(self):
        manager = FakeProcessManager([self.make_process(1421)])
        app = ProcessMonitorApp(self.root, manager)
        app.tree.selection_set("1421")
        app._on_process_selected()
        manager.details.clear()

        with patch("gui.main_window.messagebox.showwarning") as show_warning:
            result = app._open_details_window()

        self.assertIsNone(result)
        show_warning.assert_called_once()
        self.assertIn("Process unavailable", show_warning.call_args[0][0])
        self.assertIn("1421", show_warning.call_args[0][1])

    def build_app(self, processes):
        """Create the app with fake backends and an auto-refresh cancellation."""
        manager = FakeProcessManager(processes)
        controller = FakeProcessController()
        app = ProcessMonitorApp(self.root, manager, controller)
        self.addCleanup(app._cancel_auto_refresh)
        return app, manager, controller

    def select(self, app, pid):
        app.tree.selection_set(str(pid))
        app._on_process_selected()

    def test_control_without_a_selection_shows_a_warning(self):
        app, _, controller = self.build_app([self.make_process(1421)])

        with patch("gui.main_window.messagebox.showwarning") as show_warning:
            app._pause_selected_process()
            app._terminate_selected_process()

        self.assertEqual(controller.calls, [])
        self.assertEqual(show_warning.call_count, 2)
        self.assertIn("No process selected", show_warning.call_args[0][0])

    def test_pause_and_resume_send_signals_and_update_status(self):
        app, _, controller = self.build_app([self.make_process(1421)])
        self.select(app, 1421)

        app._pause_selected_process()

        self.assertEqual(controller.calls, [("pause", 1421)])
        self.assertEqual(app.status_text.get(), "Status: Paused PID 1421")

        app._resume_selected_process()

        self.assertEqual(controller.calls, [("pause", 1421), ("resume", 1421)])
        self.assertEqual(app.status_text.get(), "Status: Resumed PID 1421")

    def test_terminate_asks_for_confirmation_before_signalling(self):
        app, _, controller = self.build_app([self.make_process(1421, name="firefox")])
        self.select(app, 1421)

        with patch("gui.main_window.messagebox.askyesno", return_value=False) as ask:
            app._terminate_selected_process()

        ask.assert_called_once()
        self.assertIn("Terminate firefox (PID 1421)?", ask.call_args[0][1])
        self.assertEqual(controller.calls, [])

        with patch("gui.main_window.messagebox.askyesno", return_value=True):
            app._terminate_selected_process()

        self.assertEqual(controller.calls, [("terminate", 1421)])
        self.assertEqual(app.status_text.get(), "Status: Terminated PID 1421")

    def test_control_failure_is_reported_without_raising(self):
        app, _, controller = self.build_app([self.make_process(1421)])
        self.select(app, 1421)
        controller.error = ProcessControlError(
            "Permission denied: PID 1421 is probably owned by another user."
        )

        with patch("gui.main_window.messagebox.showerror") as show_error:
            app._pause_selected_process()

        show_error.assert_called_once()
        self.assertIn("Permission denied", show_error.call_args[0][1])
        self.assertIn("Pause failed", app.status_text.get())

    def test_terminated_process_disappears_after_a_refresh(self):
        processes = [self.make_process(1421), self.make_process(7, name="bash")]
        app, manager, _ = self.build_app(processes)
        self.select(app, 1421)

        with patch("gui.main_window.messagebox.askyesno", return_value=True):
            app._terminate_selected_process()

        manager.processes = [processes[1]]
        manager.details = {7: processes[1]}
        app.refresh()

        self.assertEqual(list(app.tree.get_children()), ["7"])
        self.assertIsNone(app.selected_pid)
        self.assertIn("no longer available", app.status_note_text.get())

    def test_auto_refresh_is_scheduled_with_after(self):
        app, _, _ = self.build_app([self.make_process(1421)])

        self.assertIsNotNone(app._auto_refresh_after_id)
        self.assertIn(app._auto_refresh_after_id, app.root.tk.call("after", "info"))
        self.assertGreaterEqual(AUTO_REFRESH_INTERVAL_MS, 1000)
        self.assertLessEqual(AUTO_REFRESH_INTERVAL_MS, 2000)

    def test_auto_refresh_tick_refreshes_and_reschedules(self):
        app, manager, _ = self.build_app([self.make_process(1421)])
        calls_before = manager.get_processes_calls

        app._auto_refresh_tick()

        self.assertEqual(manager.get_processes_calls, calls_before + 1)
        self.assertIsNotNone(app._auto_refresh_after_id)

    def test_auto_refresh_keeps_search_and_selection(self):
        processes = [self.make_process(1, name="firefox"), self.make_process(2, name="bash")]
        app, manager, _ = self.build_app(processes)
        self.type_search(app, "ba")
        self.select(app, 2)

        app._auto_refresh_tick()

        self.assertEqual(app.search_text.get(), "ba")
        self.assertEqual(list(app.tree.get_children()), ["2"])
        self.assertEqual(app.selected_pid, 2)
        self.assertEqual(app.tree.selection(), ("2",))
        self.assertIn("Showing: 1 of 2", app.process_count_text.get())

        manager.processes = []
        app._auto_refresh_tick()

        self.assertEqual(list(app.tree.get_children()), [])
        self.assertIsNone(app.selected_pid)
        self.assertIn("Selected PID: None", app.selected_pid_text.get())


if __name__ == "__main__":
    unittest.main()
