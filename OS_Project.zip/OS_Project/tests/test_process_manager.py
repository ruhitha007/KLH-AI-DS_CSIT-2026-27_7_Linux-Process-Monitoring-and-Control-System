import shutil
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from typing import Optional, Sequence
from unittest.mock import patch

from backend import process_manager
from backend.process_manager import ProcessInfo, ProcessManager


class ProcessManagerTests(unittest.TestCase):
    def setUp(self) -> None:
        temporary_directory = tempfile.TemporaryDirectory()
        self.addCleanup(temporary_directory.cleanup)
        self.proc_root = Path(temporary_directory.name)

    @staticmethod
    def make_stat(
        pid: int,
        name: str,
        state: str,
        ppid: int,
        user_ticks: int,
        system_ticks: int,
        start_time_ticks: int,
    ) -> str:
        fields = [state, str(ppid)]
        fields.extend(["0"] * 9)
        fields.extend([str(user_ticks), str(system_ticks)])
        fields.extend(["0"] * 6)
        fields.append(str(start_time_ticks))
        return f"{pid} ({name}) {' '.join(fields)}\n"

    def add_process(
        self,
        pid: int,
        name: str = "python3",
        state: str = "S",
        ppid: int = 1,
        uid: int = 1000,
        user_ticks: int = 100,
        system_ticks: int = 50,
        start_time_ticks: int = 1000,
        rss_kb: Optional[int] = 1024,
        command_line: Optional[str] = None,
    ) -> None:
        process_dir = self.proc_root / str(pid)
        process_dir.mkdir()
        (process_dir / "stat").write_text(
            self.make_stat(
                pid,
                name,
                state,
                ppid,
                user_ticks,
                system_ticks,
                start_time_ticks,
            ),
            encoding="utf-8",
        )

        rss_line = "" if rss_kb is None else f"VmRSS:\t{rss_kb} kB\n"
        (process_dir / "status").write_text(
            f"Name:\t{name}\nUid:\t{uid}\t{uid}\t{uid}\t{uid}\n{rss_line}",
            encoding="utf-8",
        )
        if command_line is not None:
            (process_dir / "cmdline").write_bytes(
                (command_line + "\0").encode("utf-8")
            )

    def make_manager(self, timestamps: Sequence[float] = ()) -> ProcessManager:
        if timestamps:
            values = iter(timestamps)

            def monotonic_time() -> float:
                return next(values)
        else:
            monotonic_time = process_manager.time.monotonic

        return ProcessManager(
            self.proc_root,
            clock_ticks=100,
            monotonic_time=monotonic_time,
        )

    def test_get_processes_discovers_numeric_entries_only(self) -> None:
        self.add_process(42, name="editor", state="R", ppid=10)
        self.add_process(7)
        (self.proc_root / "self").write_text("not a process", encoding="utf-8")
        (self.proc_root / "123abc").mkdir()

        fake_pwd = SimpleNamespace(
            getpwuid=lambda uid: SimpleNamespace(pw_name=f"user{uid}")
        )
        with patch.object(process_manager, "pwd", fake_pwd):
            processes = ProcessManager(self.proc_root).get_processes()

        self.assertEqual(
            processes,
            [
                ProcessInfo(7, "python3", "S", 1, "user1000"),
                ProcessInfo(42, "editor", "R", 10, "user1000"),
            ],
        )

    def test_get_process_info_parses_name_with_spaces_and_parentheses(self) -> None:
        self.add_process(123, name="worker (ready)", state="R", ppid=45)

        process = ProcessManager(self.proc_root).get_process_info(123)

        self.assertIsNotNone(process)
        self.assertEqual(process.name, "worker (ready)")
        self.assertEqual(process.state, "R")
        self.assertEqual(process.ppid, 45)

    def test_process_that_disappears_is_skipped(self) -> None:
        self.add_process(100)
        (self.proc_root / "99").mkdir()

        manager = ProcessManager(self.proc_root)
        processes = manager.get_processes()

        self.assertEqual([process.pid for process in processes], [100])
        self.assertIsNone(manager.get_process_info(99))

    def test_permission_error_on_stat_returns_none(self) -> None:
        self.add_process(200)

        with patch.object(Path, "read_text", side_effect=PermissionError("denied")):
            process = ProcessManager(self.proc_root).get_process_info(200)

        self.assertIsNone(process)

    def test_permission_error_on_status_keeps_process_without_username(self) -> None:
        self.add_process(300)
        original_read_text = Path.read_text

        def read_text(path, *args, **kwargs):
            if path.name == "status":
                raise PermissionError("denied")
            return original_read_text(path, *args, **kwargs)

        with patch.object(Path, "read_text", new=read_text):
            process = ProcessManager(self.proc_root).get_process_info(300)

        self.assertIsNotNone(process)
        self.assertEqual(process.pid, 300)
        self.assertIsNone(process.username)

    def test_cpu_usage_calculates_change_between_two_samples(self) -> None:
        self.add_process(
            400,
            user_ticks=200,
            system_ticks=100,
            start_time_ticks=5000,
        )
        manager = self.make_manager([10.0, 12.0])
        manager.capture_cpu_baseline()

        (self.proc_root / "400" / "stat").write_text(
            self.make_stat(400, "python3", "R", 1, 350, 100, 5000),
            encoding="utf-8",
        )
        cpu_percent = manager.get_cpu_usage(400)

        self.assertIsNotNone(cpu_percent)
        self.assertAlmostEqual(cpu_percent, 75.0)

    def test_cpu_usage_handles_disappearing_and_malformed_processes(self) -> None:
        self.add_process(401, start_time_ticks=5000)
        self.add_process(402, start_time_ticks=5000)
        manager = self.make_manager([10.0])
        manager.capture_cpu_baseline()

        shutil.rmtree(self.proc_root / "401")
        (self.proc_root / "402" / "stat").write_text(
            "402 (broken) S invalid-ppid\n",
            encoding="utf-8",
        )

        self.assertIsNone(manager.get_cpu_usage(401))
        self.assertIsNone(manager.get_cpu_usage(402))

    def test_memory_usage_uses_rss_and_total_physical_memory(self) -> None:
        self.add_process(500, rss_kb=262144)
        (self.proc_root / "meminfo").write_text(
            "MemTotal:       1048576 kB\nMemFree:         500000 kB\n",
            encoding="utf-8",
        )
        manager = self.make_manager()

        memory_percent = manager.get_memory_usage(500)

        self.assertIsNotNone(memory_percent)
        self.assertAlmostEqual(memory_percent, 25.0)

        with patch.object(Path, "read_text", side_effect=PermissionError("denied")):
            self.assertIsNone(manager.get_memory_usage(500))

        (self.proc_root / "meminfo").write_text(
            "MemTotal:       invalid kB\n",
            encoding="utf-8",
        )
        self.assertIsNone(manager.get_memory_usage(500))

    def test_command_line_uses_nul_separated_proc_data(self) -> None:
        self.add_process(600, command_line="python3\0main.py\0--demo")
        self.add_process(601, command_line="")
        manager = self.make_manager()

        self.assertEqual(
            manager.get_command_line(600),
            "python3 main.py --demo",
        )
        self.assertIsNone(manager.get_command_line(601))

        with patch.object(Path, "read_bytes", side_effect=PermissionError("denied")):
            self.assertIsNone(manager.get_command_line(600))

    def test_process_details_include_command_runtime_and_memory(self) -> None:
        self.add_process(
            700,
            user_ticks=200,
            system_ticks=100,
            start_time_ticks=20000,
            rss_kb=262144,
            command_line="python3\0main.py",
        )
        (self.proc_root / "meminfo").write_text(
            "MemTotal:       1048576 kB\n",
            encoding="utf-8",
        )
        (self.proc_root / "uptime").write_text(
            "1000.0 900.0\n",
            encoding="utf-8",
        )

        details = self.make_manager().get_process_details(700)

        self.assertIsNotNone(details)
        self.assertEqual(details.command_line, "python3 main.py")
        self.assertEqual(details.runtime_seconds, 800.0)
        self.assertAlmostEqual(details.memory_percent, 25.0)
        self.assertIsNone(details.cpu_percent)


if __name__ == "__main__":
    unittest.main()
