import errno
import os
import re
import signal
import unittest
from unittest.mock import patch

from backend.process_controller import (
    PAUSE_SIGNAL,
    RESUME_SIGNAL,
    TERMINATE_SIGNAL,
    ProcessControlError,
    ProcessController,
)


# POSIX signal numbers, used so the tests behave the same on any platform.
POSIX_SIGSTOP = 19
POSIX_SIGCONT = 18
POSIX_SIGTERM = 15


class RecordingProcessController(ProcessController):
    """ProcessController subclass that records signals instead of sending them."""

    def __init__(self):
        super().__init__(send_signal=self._record)
        # On Windows the module constants are None, so use the POSIX numbers to
        # keep the recording tests platform independent.
        self.pause_signal = PAUSE_SIGNAL if PAUSE_SIGNAL is not None else POSIX_SIGSTOP
        self.resume_signal = (
            RESUME_SIGNAL if RESUME_SIGNAL is not None else POSIX_SIGCONT
        )
        self.terminate_signal = (
            TERMINATE_SIGNAL if TERMINATE_SIGNAL is not None else POSIX_SIGTERM
        )
        self.sent = []
        self.error = None

    def _record(self, pid, sig):
        if self.error is not None:
            raise self.error
        self.sent.append((pid, sig))


class ProcessControllerTests(unittest.TestCase):
    def setUp(self):
        self.controller = RecordingProcessController()

    def assertSignalSent(self, expected_signal):
        self.assertEqual(self.controller.sent, [(4242, expected_signal)])

    def test_pause_sends_sigstop(self):
        self.controller.pause_process(4242)

        self.assertSignalSent(POSIX_SIGSTOP)

    def test_resume_sends_sigcont(self):
        self.controller.resume_process(4242)

        self.assertSignalSent(POSIX_SIGCONT)

    def test_terminate_sends_sigterm(self):
        self.controller.terminate_process(4242)

        self.assertSignalSent(POSIX_SIGTERM)

    @unittest.skipUnless(
        hasattr(signal, "SIGSTOP"),
        "POSIX stop signals are only defined on Linux-like platforms",
    )
    def test_signals_are_the_real_posix_numbers(self):
        self.assertEqual(PAUSE_SIGNAL, signal.SIGSTOP)
        self.assertEqual(RESUME_SIGNAL, signal.SIGCONT)
        self.assertEqual(TERMINATE_SIGNAL, signal.SIGTERM)

    def test_default_controller_uses_os_kill(self):
        controller = ProcessController()
        controller.pause_signal = POSIX_SIGSTOP

        with patch("os.kill") as kill:
            controller.pause_process(99)

        kill.assert_called_once_with(99, POSIX_SIGSTOP)

    def test_invalid_pids_are_rejected_without_signalling(self):
        for invalid_pid in (0, -1, "4242", None, 1.5, True):
            with self.subTest(pid=invalid_pid):
                with self.assertRaises(ProcessControlError):
                    self.controller.pause_process(invalid_pid)

        self.assertEqual(self.controller.sent, [])

    def test_missing_process_reports_that_it_disappeared(self):
        self.controller.error = ProcessLookupError(errno.ESRCH, "No such process")

        with self.assertRaises(ProcessControlError) as caught:
            self.controller.terminate_process(4242)

        self.assertEqual(caught.exception.pid, 4242)
        self.assertIn("no longer exists", str(caught.exception))

    def test_permission_error_is_reported_cleanly(self):
        self.controller.error = PermissionError(errno.EPERM, "Operation not permitted")

        with self.assertRaises(ProcessControlError) as caught:
            self.controller.resume_process(4242)

        self.assertIn("Permission denied", str(caught.exception))

    def test_other_os_errors_are_wrapped(self):
        self.controller.error = OSError(errno.EINVAL, "Invalid argument")

        with self.assertRaises(ProcessControlError) as caught:
            self.controller.pause_process(4242)

        self.assertIn("Invalid argument", str(caught.exception))
        self.assertEqual(caught.exception.pid, 4242)

    def test_only_stop_cont_and_term_are_available(self):
        controller_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "backend",
            "process_controller.py",
        )
        with open(controller_path, encoding="utf-8") as source_file:
            source = source_file.read()

        used_signals = set(re.findall(r'"(SIG\w+)"', source))
        self.assertEqual(used_signals, {"SIGSTOP", "SIGCONT", "SIGTERM"})

        for forbidden in ("os.system", "subprocess", "popen", "os.popen"):
            with self.subTest(forbidden=forbidden):
                self.assertNotIn(forbidden, source)


if __name__ == "__main__":
    unittest.main()
